def classFactory(iface):
    from .main import QgisSupabaseSyncPlugin
    return QgisSupabaseSyncPlugin(iface)
